<div id="sidebar">
						<div class="inner">						

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="index.php">Homepage</a></li>
										<li><a href="research.php">Research Interests</a></li>
										<li><a href="work.php">Work & Education</a></li>
										<li><a href="publications.php">Publications</a></li>
										<li><a href="projects.php">Projects</a></li>
										<li><a href="teaching.php">Teaching</a></li>
										<li><a href="courses.php">Courses</a></li>
										<li><a href="misc.php">Misc</a></li>
                                        <li><a href="news.php">News</a></li>
									</ul>
								</nav>

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Latest News</h2>
									</header>
									<div class="mini-posts">
										<ul>
                                            <li><a href="#">Demo News Title</a></li>
                                            <li><a href="#">Demo News Title</a></li>
                                            <li><a href="#">Demo News Title</a></li>
                                        </ul>
										
										
									</div>
									<ul class="actions">
										<li><a href="news.php" class="button">More</a></li>
									</ul>
								</section>

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Get in touch</h2>
									</header>
									
									<ul class="contact">
										<li class="fa-envelope-o"><a href="#">muk392@psu.edu</a></li>
										<li class="fa-phone">+1-813-204-0617</li>
										<li class="fa-home">State College, Pennsylvania</li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; Nasim Imtiaz. All rights reserved.</p>
								</footer>

						</div>
					</div>