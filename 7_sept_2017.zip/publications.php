<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Nasim Imtiaz Khan || PHD Student</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<?php include ('header.php'); ?>

							<!-- Content -->
								<section>
									<header class="main">
										
									</header>

									<h2 align="center">Publications</h2>
                                    <p>
                                    US Patent:
                                        <ul>
                                        	<li>Strap Region Exploit Mu-Metal Nano-Shielding from Magnetic Field Attack on STTRAM (pending)</li>
                                        </ul>
                                    </p>
                                    <p>
                                    Journal(s):
                                        <ul>
                                            <li>Mohammad Nasim Imtiaz Khan, Anirudh Iyengar & Swaroop Ghosh, “Novel Magnetic Burn-In for Retention and Magnetic Tolerance Testing of STTRAM”, submitted for review, IEEE Transactions on Very Large Scale Integration Systems (TVLSI).</li>
                                            <li>Asmit De, Mohammad Nasim Imtiaz Khan and Swaroop Ghosh, “Attack resilient architecture to replace embedded Flash with STTRAM in homogeneous IoTs”, submitted for review, IEEE Transactions on Very Large Scale Integration Systems (TVLSI).</li>
                                            <li>Md. Ziaur Rahman Khan, Md. Zadid Khan, Mohammad Nasim Imtiaz Khan, Shammya Shananda Saha, Dewan Fahim Noor and Md. Rifat Kaisar Rachi, "Maximum Power Point Tracking for Photovoltaic Array Using Parabolic Interpolation," International Journal of Information and Electronics Engineering (IJIEE), 2014.</li>
                                        </ul>
                                    </p>
                                    <p>
                                    
                                    Conference Paper(s):
                                    <ul>
                                    	<li>Mohammad Nasim Imtiaz Khan, Anirudh Iyengar & Swaroop Ghosh, “Novel Magnetic Burn-In for Retention Testing of STTRAM”, Accepted in DATE, 2017. (Acceptance Rate 24%)</li>
                                        <li>Swaroop Ghosh, Mohammad Nasim Imtiaz Khan, Asmit De and Jae-Won Jang, “Security and privacy threats to on-chip non-volatile memories and countermeasures”, ICCAD, 2017. (Acceptance Rate 25%)</li>
                                        <li>Mohammad Nasim Imtiaz Khan, Dewan Fahim Noor, Md. Jubaer Hossain Pantho, Tahmid Syed Abtahi, Farhana Parvin and Mohammed Imamul Hassan Bhuiyan, "A low cost optical sensor based heart rate monitoring system," ICIEV, 2013. (Acceptance Rate 42%)</li>
                                        <li>Mohammad Nasim Imtiaz Khan, Md Zadid Khan, Dewan Fahim Noor, Adib Nahiyan, Md Ehsanul Haque, Shammya Shananda Saha, Md Rifat Kaisar Rachi and Md Ziaur Rahman Khan, "Modelling and Simulation of an Efficient Charge Controller for Photovoltaic System with Maximum Power Point Tracking", ICDRET, 2014. </li>
                                        </ul>


									<hr class="major" />				

									

									

								</section>

						</div>
					</div>

				<!-- Sidebar -->
					<?php
						include ('sidebar.php');
					?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>