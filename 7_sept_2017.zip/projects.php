<!DOCTYPE HTML>

<html>
	<head>
		<title>Nasim Imtiaz Khan || PHD Student</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<?php include ('header.php'); ?>

							<!-- Content -->
								<section>
									<header class="main">
										
									</header>									

									<h2 align="center">Projects</h2>
<p>
CLASS PROJECTS
<ul>
<li>Design and implementation of a Heart Beat Counter - Sensing blood rush in vein using phototransistor, signal processing to calculate beat per minute (BPM).</li>
<li>Design circuit and layout of n-bit comparator using Cadence Virtuoso software. </li>
<li>Design and simulation of a 8-bit Micro-computer - Able to perform 16 mathematical operation.</li>
<li>Design and implementation of hardware based ‘Breakout’ using Basic latch-gate.</li>
<li>Analysis of Acoustic Characteristics of a class room- Attenuation profile, delay profile, reverberation characteristics and noise level. </li>
<li>Design of a Chess Playing Robot with Artificial Intelligence.</li>
<li>Designed and implemented Object Detecting Voice Controlled Robot and Maze solving Robot.</li>
<li>Design and implementation of Autonomous Mining Robot- Can dig and carry up to 66 lbs. lunar regolith.</li>
</ul>

									<hr class="major" />

									

								

									

								</section>

						</div>
					</div>

				<!-- Sidebar -->
					<?php
						include ('sidebar.php');
					?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>