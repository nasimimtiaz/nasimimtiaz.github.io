<!DOCTYPE HTML>

<html>
	<head>
		<title>Nasim Imtiaz Khan || PHD Student</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<?php include ('header.php'); ?>

							<!-- Content -->
								<section>
									<header class="main">
										
									</header>

									<p>
                                    <h2 align="center">Research Interests</h2>
                                    My research is focused towards hardware security and low-power circuit design with emerging devices. In particular, I am interested in the following topics:
                                    <ul>
                                    	<li>Test Characterization of Non-Volatile Memory: In this project, I proposed novel magnetic burn-in test which can be implemented with minimal changes in the existing test flow to enable STTRAM retention testing at short test time. </li>
                                        <li>Attack resilient architecture to replace embedded Flash with STTRAM in homogeneous IoTs – In this project I am investigating information redundancy present in a homogeneous peer-to-peer connected IoT network which can be exploited to restore the corrupted memory of any IoT node after a magnetic attack. </li>
                                        <li>Nano-Shielding STTRAM using Mu-Metal from Magnetic Field Attack: In this project, I proposed a low-overhead solution for protection against magnetic field attack which exploits structure of STTRAM tape layout to bypass the magnetic flux through mu-metal. </li>
                                        <li>Multi-Bit Read and Write Methodologies for Crossbar Array – In this project, I proposed a technique to perform multi-bit read and write in a diode-STTRAM crossbar array.</li>
                                        <li>Novel Non-Volatile Memory (NVM) based device for efficient computation: In this project, I am investigating a novel NVM device that can be used for addition, multiplication, sorting, etc. in an energy-efficient way compared to CMOS.</li>
                                   </ul>

                                    
                                    
                                    
                                    </p>
									

									


									<hr class="major" />

									<!--<h2>Lorem aliquam bibendum</h2>
									<p>Donec eget ex magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Pellentesque venenatis dolor imperdiet dolor mattis sagittis. Praesent rutrum sem diam, vitae egestas enim auctor sit amet. Pellentesque leo mauris, consectetur id ipsum sit amet, fergiat. Pellentesque in mi eu massa lacinia malesuada et a elit. Donec urna ex, lacinia in purus ac, pretium pulvinar mauris. Curabitur sapien risus, commodo eget turpis at, elementum convallis elit. Pellentesque enim turpis, hendrerit.</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis dapibus rutrum facilisis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Etiam tristique libero eu nibh porttitor fermentum. Nullam venenatis erat id vehicula viverra. Nunc ultrices eros ut ultricies condimentum. Mauris risus lacus, blandit sit amet venenatis non, bibendum vitae dolor. Nunc lorem mauris, fringilla in aliquam at, euismod in lectus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In non lorem sit amet elit placerat maximus. Pellentesque aliquam maximus risus, vel sed vehicula.</p>-->

								</section>

						</div>
					</div>

				<!-- Sidebar -->
					<?php
						include ('sidebar.php');
					?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>